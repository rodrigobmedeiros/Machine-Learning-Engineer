from setuptools import setup

setup(name='gaussbin_distributions',
      version='1.0',
      description='Gaussian and Binomial distribution',
      packages=['gaussbin_distributions'],
      author='Rodrigo Bernardo Medeiros',
      author_email='rodrimedeiros@gmail.com',
      zip_safe=False)
